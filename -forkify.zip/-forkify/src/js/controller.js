import * as model from './model.js';
import recipeView from './views/recipeView.js';
import searchView from './views/searchView.js';
import resultsView from './views/resultsView.js';
import bookmarkView from './views/bookmarkView.js';
import addRecipeView from './views/addRecipeView.js';
import paginationView from './views/paginationView.js';
import 'core-js/stable';
import 'regenerator-runtime';

// const timeout = function (s) {
//   return new Promise(function (_, reject) {
//     setTimeout(function () {
//       reject(new Error(`Request took too long! Timeout after ${s} second`));
//     }, s * 1000);
//   });
// };

const controlRecipe = async function(){
  try{

    const hashId = window.location.hash.slice(1);
    if(!hashId) return;
    recipeView.renderSpinner();
    
    resultsView.update(model.getSearchResultsPage());
    bookmarkView.update(model.state.bookmarks);
    
    //Load Recipe
    await model.loadRecipe(hashId);

    //Render Recipe
    recipeView.render(model.state.recipe);
    // model.state.recipe

  } catch(err){

  }

}

async function controlSearcResults(){
  try {
    resultsView.renderSpinner();
    const query = searchView.getQuery();
    if(!query) return;

    await model.loadsearchResults(query);

    // resultsView.render(model.state.search.results);
    resultsView.render(model.getSearchResultsPage());

    //render initial pagination
    paginationView.render(model.state.search);
  } catch (error) {
   console.log(error) 
  }
}

function controlPagination(goto){
  resultsView.render(model.getSearchResultsPage(goto));
  paginationView.render(model.state.search); 
}


function controlServings(newServ){
 model.updateServings(newServ);
 recipeView.update(model.state.recipe); 
}

const controlAddBoookmarks = function(){
  if(!model.state.recipe.bookmarked){
     model.addBookMark(model.state.recipe);
     console.log(model.state.recipe)
  }
  else{
     model.deleteBookMark(model.state.recipe.id);
  }
  
  recipeView.update(model.state.recipe);

  bookmarkView.render(model.state.bookmarks);
}

const controlBookmarks = function(){
  bookmarkView.render(model.state.bookmarks);
}

async function controlAddRecipe(newRecipe){
  try{
    addRecipeView.renderSpinner();

    await model.uploadRecipe(newRecipe);
    recipeView.render(model.state.recipe);

    addRecipeView.renderMessage();

    bookmarkView.render(model.state.bookmarks);

    Window.history.pushState(null, '', `#${model.state.recipe.id}`);
    console.log(model.state.recipe)
  }catch(err){
    console.log(err);
  }
}

function init(){
  bookmarkView.addHandlerRender(controlBookmarks);
  recipeView.addHandlerRender(controlRecipe);
  recipeView.addHandlerUpdateServings(controlServings);
  recipeView.addHandlerBookmark(controlAddBoookmarks);
  searchView.addHandlerSearch(controlSearcResults);
  paginationView.addHandlerClick(controlPagination);
  addRecipeView.addHandlerUpload(controlAddRecipe);
}

init();

