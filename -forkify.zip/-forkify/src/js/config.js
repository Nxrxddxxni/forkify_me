export const API_URL = 'https://forkify-api.herokuapp.com/api/v2/recipes/';
export const RES_PER_PAGE = 10;
export const API_KEY = '7b6e6a93-971d-42a6-9cd3-ca9c6bef1dcb';